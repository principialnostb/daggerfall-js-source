# Smart PaperDoll integration kit

## What this adds

- A selectable preset descriptor: **Smart PaperDoll** (`id: smart-paperdoll`).
- A runtime adapter that rebuilds the voxel-column figure when the finished PaperDoll `version` changes.
- A registry helper that appends the preset without deleting or changing the developer presets.
- Unit tests for registration, version-based refresh, missing pixels, and required inputs.

## The critical image-source rule

The public repository's `paperDollPixels()` returns the finished panel composite; that can include the panel backdrop. Do not feed it directly into the voxelizer. Feed the adapter a foreground-only image, ideally produced by the already-exported:

```js
composePaperDollPixels(deps, playerEntity, { background: false })
```

The returned object should be exposed as:

```js
{ version: paperDollVersion, pixels: { width, height, rgba } }
```

Use the exact same PaperDoll compositor that already handles the currently loaded texture replacements and mods. Do not read or rewrite inventory icons, and do not rebuild appearance from equipment slots.

## Required host integration

The current public main branch has a Morrowind rigged-mesh third-person body (`mwView.js` -> `fpArm.drawThird`) as well as the PaperDoll compositor. The module here creates voxel columns but does **not** yet adapt them to the live renderer's bones/animation/shadow/collision contracts.

To complete the UI selection:
1. Import `SMART_PAPERDOLL_PRESET` and `withSmartPaperDollPreset` in the file that declares the existing player-model preset list.
2. Append the descriptor to that list; do not replace stock presets.
3. When selected, instantiate `createSmartPaperDollSkin({ getFigurePixels })`.
4. Expose a figure-only PaperDoll pixel provider from the same compositor, with a version that increments whenever the composite changes.
5. Add a renderer bridge that converts the returned voxel columns to the engine's supported mesh format. Keep the original renderer as fallback if the build fails or the player is transformed (for example, werewolf).

The exact preset-list file and renderer bridge need to be changed in the user's checkout. The available public source confirms the PaperDoll and third-person entry points, but this isolated kit intentionally does not overwrite those central files without testing against the checkout's exact revision.

## Paperdoll Enhanced (Nexus mod 748)

The mod is a texture replacement for Daggerfall Unity. The dynamic path should consume the final image after this project's own texture-replacement pipeline has loaded the replacement. A Unity `.dfmod` file is not automatically imported by the JavaScript port. No art from the mod is bundled or copied here.
