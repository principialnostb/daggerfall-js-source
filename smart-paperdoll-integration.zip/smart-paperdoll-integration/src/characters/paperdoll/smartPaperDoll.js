/**
 * Smart PaperDoll skin preset adapter.
 *
 * This is the runtime-facing contract for the new selectable preset. The
 * host's preset selector should register SMART_PAPERDOLL_PRESET and route its
 * "build" call here. It consumes the *finished foreground-only PaperDoll
 * buffer*, never equipment slots or item icons.
 *
 * This adapter intentionally does not import the renderer: the current
 * third-person renderer expects a rigged Morrowind mesh, whereas this feature
 * produces a shallow voxel relief. A host-specific draw adapter must turn
 * `model.voxels` into renderer geometry before it can replace the in-world
 * body.
 */
import { paperDollToVoxelColumns } from './paperDollVoxelizer.js';

export const SMART_PAPERDOLL_ID = 'smart-paperdoll';

export const SMART_PAPERDOLL_PRESET = Object.freeze({
  id: SMART_PAPERDOLL_ID,
  label: 'Smart PaperDoll',
  description: 'Dynamically builds the player figure from the current PaperDoll appearance.',
  category: 'dynamic',
  dynamic: true,
  // Deliberately no fixed texture/model asset: appearance is built at runtime.
  asset: null,
});

export function createSmartPaperDollSkin({
  getFigurePixels,
  onModelChanged = null,
  pixelStep = 1,
  depth = 2,
} = {}) {
  if (typeof getFigurePixels !== 'function') {
    throw new TypeError('getFigurePixels must return the current foreground-only PaperDoll pixels');
  }

  let lastVersion = null;
  let model = null;
  let building = false;

  return Object.freeze({
    id: SMART_PAPERDOLL_ID,
    preset: SMART_PAPERDOLL_PRESET,

    /**
     * Poll from the host's character/model update path.
     * Returns cached model until PaperDoll's version changes.
     */
    update() {
      const frame = getFigurePixels();
      if (!frame || !frame.pixels) return model;
      const pixels = frame.pixels;
      if (frame.version === lastVersion && model) return model;
      if (building) return model;
      building = true;
      try {
        model = paperDollToVoxelColumns({
          width: pixels.width,
          height: pixels.height,
          rgba: pixels.rgba ?? pixels.data,
        }, {
          pixelStep,
          depth,
          alphaThreshold: 8,
        });
        lastVersion = frame.version;
        onModelChanged?.(model, frame.version);
      } finally {
        building = false;
      }
      return model;
    },

    current() { return model; },
    version() { return lastVersion; },
    invalidate() { lastVersion = null; },
  });
}

/**
 * Preset registry helper: keeps the stock presets and adds this one.
 * Use this when the existing selector is driven by an array of preset objects.
 */
export function withSmartPaperDollPreset(stockPresets) {
  const presets = Array.isArray(stockPresets) ? stockPresets : [];
  return presets.some(p => p?.id === SMART_PAPERDOLL_ID)
    ? presets
    : [...presets, SMART_PAPERDOLL_PRESET];
}
