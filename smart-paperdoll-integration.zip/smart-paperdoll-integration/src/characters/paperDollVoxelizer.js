/**
 * PaperDoll -> voxel columns.
 *
 * This module intentionally does not import renderer/game modules. It converts
 * a transparent RGBA PaperDoll foreground into colored voxel columns that can
 * be uploaded by the existing character renderer.
 *
 * Important: src/ui/paperDoll.js currently exports paperDollPixels() as the
 * finished *panel composite*. In the normal path that composite can include
 * the opaque panel background. Do NOT pass that buffer directly here unless
 * you have first produced a figure-only buffer / alpha mask.
 */

/**
 * Convert a figure-only RGBA image into voxel columns.
 *
 * One source pixel (or one block of `pixelStep` source pixels) becomes a
 * column of `depth` voxels. The source image is front-facing; the depth is
 * deliberately uniform because a single 2D paper doll does not contain
 * enough information to infer true side/back geometry.
 *
 * @param {{width:number,height:number,rgba:Uint8Array|Uint8ClampedArray}} image
 * @param {{pixelStep?:number,depth?:number,alphaThreshold?:number,
 *          centerX?:boolean,centerY?:boolean,transparentColor?:[number,number,number],
 *          transparentTolerance?:number}} options
 * @returns {{width:number,height:number,depth:number,voxels:Array<{
 *   x:number,y:number,z:number,r:number,g:number,b:number,a:number}>,
 *   bounds:{minX:number,maxX:number,minY:number,maxY:number,minZ:number,maxZ:number}}}
 */
export function paperDollToVoxelColumns(image, options = {}) {
  validateImage(image);
  const pixelStep = positiveInt(options.pixelStep ?? 1, 'pixelStep');
  const depth = positiveInt(options.depth ?? 2, 'depth');
  const alphaThreshold = clampInt(options.alphaThreshold ?? 8, 0, 255);
  const transparentColor = options.transparentColor ?? null;
  const tolerance = clampInt(options.transparentTolerance ?? 0, 0, 255);
  if (transparentColor && (!Array.isArray(transparentColor) || transparentColor.length < 3)) {
    throw new TypeError('transparentColor must be [r,g,b]');
  }

  const { width, height, rgba } = image;
  const outWidth = Math.ceil(width / pixelStep);
  const outHeight = Math.ceil(height / pixelStep);
  const voxels = [];
  let minX = Infinity, maxX = -Infinity;
  let minY = Infinity, maxY = -Infinity;
  let minZ = Infinity, maxZ = -Infinity;

  const isForeground = (i) => {
    const a = rgba[i + 3];
    if (a <= alphaThreshold) return false;
    if (!transparentColor || tolerance === 0) return true;
    const dr = rgba[i] - transparentColor[0];
    const dg = rgba[i + 1] - transparentColor[1];
    const db = rgba[i + 2] - transparentColor[2];
    return Math.sqrt(dr * dr + dg * dg + db * db) > tolerance;
  };

  for (let oy = 0; oy < outHeight; oy++) {
    for (let ox = 0; ox < outWidth; ox++) {
      // Average visible source pixels in a block, preserving modded colors
      // while avoiding a nearest-neighbor bias when downsampling hi-res mods.
      let r = 0, g = 0, b = 0, a = 0, n = 0;
      const xEnd = Math.min(width, (ox + 1) * pixelStep);
      const yEnd = Math.min(height, (oy + 1) * pixelStep);
      for (let sy = oy * pixelStep; sy < yEnd; sy++) {
        for (let sx = ox * pixelStep; sx < xEnd; sx++) {
          const i = (sy * width + sx) * 4;
          if (!isForeground(i)) continue;
          const alpha = rgba[i + 3] / 255;
          r += rgba[i] * alpha;
          g += rgba[i + 1] * alpha;
          b += rgba[i + 2] * alpha;
          a += rgba[i + 3];
          n++;
        }
      }
      if (!n) continue;

      const cr = Math.round(r / n), cg = Math.round(g / n), cb = Math.round(b / n);
      const ca = Math.round(a / n);
      const x = options.centerX === false ? ox : ox - (outWidth - 1) / 2;
      const y = options.centerY === false ? oy : outHeight - 1 - oy;

      // Front face is z=0; the remaining layers provide a simple, stable
      // thickness. Side/back colors are shaded slightly, never recolored.
      for (let z = 0; z < depth; z++) {
        const shade = z === 0 ? 1 : (z === depth - 1 ? 0.68 : 0.82);
        voxels.push({
          x, y, z,
          r: Math.round(cr * shade),
          g: Math.round(cg * shade),
          b: Math.round(cb * shade),
          a: ca,
        });
        minX = Math.min(minX, x); maxX = Math.max(maxX, x);
        minY = Math.min(minY, y); maxY = Math.max(maxY, y);
        minZ = Math.min(minZ, z); maxZ = Math.max(maxZ, z);
      }
    }
  }

  return {
    width: outWidth, height: outHeight, depth, voxels,
    bounds: voxels.length
      ? { minX, maxX, minY, maxY, minZ, maxZ }
      : { minX: 0, maxX: -1, minY: 0, maxY: -1, minZ: 0, maxZ: -1 },
  };
}

/** Build a binary alpha mask from a separate figure mask, without changing RGBA. */
export function alphaMaskToRgba(image, mask, { alphaThreshold = 1 } = {}) {
  validateImage(image);
  if (!(mask instanceof Uint8Array || mask instanceof Uint8ClampedArray) ||
      mask.length !== image.width * image.height) {
    throw new TypeError('mask must be a byte array with width*height entries');
  }
  const rgba = new Uint8ClampedArray(image.rgba);
  const threshold = clampInt(alphaThreshold, 0, 255);
  for (let p = 0; p < mask.length; p++) {
    if (mask[p] < threshold) rgba[p * 4 + 3] = 0;
  }
  return { ...image, rgba };
}

function validateImage(image) {
  if (!image || !Number.isInteger(image.width) || image.width <= 0 ||
      !Number.isInteger(image.height) || image.height <= 0 ||
      !(image.rgba instanceof Uint8Array || image.rgba instanceof Uint8ClampedArray) ||
      image.rgba.length !== image.width * image.height * 4) {
    throw new TypeError('image must be {width,height,rgba} with exactly width*height*4 bytes');
  }
}
function positiveInt(value, name) {
  if (!Number.isInteger(value) || value < 1) throw new RangeError(`${name} must be a positive integer`);
  return value;
}
function clampInt(value, min, max) {
  if (!Number.isFinite(value)) throw new TypeError('expected a finite number');
  return Math.max(min, Math.min(max, Math.round(value)));
}
