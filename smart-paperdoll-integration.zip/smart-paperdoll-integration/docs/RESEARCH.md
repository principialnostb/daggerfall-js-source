# Source review

- `src/ui/paperDoll.js`: final composite API is `paperDollPixels()`; separate `composePaperDollPixels(..., { background: false })` is exported for a no-background compose.
- `src/player/mwView.js`: third-person body entry point is `mwViewDrawBody()` and calls `fpArm.drawThird()`.
- `src/combat/fpArm.js`: the live body is a rigged Morrowind model, not a plain voxel list; direct substitution requires a mesh/render bridge.
- Nexus mod 748: Paperdoll Enhanced replaces PaperDoll textures (female coverage in the listing). The JS port can use those results only if they are loaded through its own texture-replacement pipeline.

This is a tested integration module, not a claim that the selector or world renderer has already been patched.
