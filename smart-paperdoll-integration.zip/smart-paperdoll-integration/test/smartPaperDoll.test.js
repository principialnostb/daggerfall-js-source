import test from 'node:test';
import assert from 'node:assert/strict';
import {
  SMART_PAPERDOLL_ID, SMART_PAPERDOLL_PRESET,
  createSmartPaperDollSkin, withSmartPaperDollPreset,
} from '../src/characters/paperdoll/smartPaperDoll.js';

test('preset has a stable id and human-readable label', () => {
  assert.equal(SMART_PAPERDOLL_PRESET.id, 'smart-paperdoll');
  assert.equal(SMART_PAPERDOLL_PRESET.label, 'Smart PaperDoll');
  assert.equal(SMART_PAPERDOLL_PRESET.asset, null);
});

test('registration preserves stock presets and avoids duplicates', () => {
  const stock = [{ id: 'developer-preset-a' }];
  const combined = withSmartPaperDollPreset(stock);
  assert.equal(combined.length, 2);
  assert.equal(combined[0], stock[0]);
  assert.equal(combined[1].id, SMART_PAPERDOLL_ID);
  assert.equal(withSmartPaperDollPreset(combined), combined);
});

test('model is rebuilt only when the PaperDoll version changes', () => {
  let version = 1;
  let builds = 0;
  let changed = 0;
  const rgba = new Uint8ClampedArray([180, 90, 40, 255]);
  const skin = createSmartPaperDollSkin({
    getFigurePixels: () => ({ version, pixels: { width: 1, height: 1, rgba } }),
    onModelChanged: () => changed++,
    depth: 2,
  });
  const first = skin.update();
  assert.equal(first.voxels.length, 2);
  skin.update();
  assert.equal(changed, 1);
  version = 2;
  const second = skin.update();
  assert.notEqual(second, first);
  assert.equal(changed, 2);
  builds++;
  assert.equal(builds, 1); // keeps this test's assertions intentionally simple
});

test('no figure pixels returns current model without throwing', () => {
  const skin = createSmartPaperDollSkin({ getFigurePixels: () => null });
  assert.equal(skin.update(), null);
});

test('requires a pixel provider', () => {
  assert.throws(() => createSmartPaperDollSkin(), /getFigurePixels/);
});
